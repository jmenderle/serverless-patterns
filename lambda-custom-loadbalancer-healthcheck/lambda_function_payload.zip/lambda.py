def lambda_handler(event, context):
    """
    A simple AWS Lambda function that returns a "Hello, World!" message.
    
    Args:
        event (dict): The event data that triggered the Lambda function.
        context (object): Provides information about the invocation, function, and runtime environment.
    
    Returns:
        dict: A dictionary containing the response message.
    """
    return {
        'statusCode': 200,
        'body': 'Hello, World!'
    }
